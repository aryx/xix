	TEXT	NaN+0(SB),0,$0
	JAL	__NaN+0(SB)
	RET	
	RET	
	TEXT	Inf+0(SB),0,$4
	JAL	__Inf+0(SB)
	RET	
	RET	
	TEXT	isNaN+0(SB),0,$8
	MOVD	x+0(FP),F4
	MOVD	F4,4(R29)
	JAL	__isNaN+0(SB)
	RET	
	RET	
	TEXT	isInf+0(SB),0,$12
	MOVD	x+0(FP),F4
	MOVW	sign+8(FP),R3
	MOVD	F4,4(R29)
	MOVW	R3,12(R29)
	JAL	__isInf+0(SB)
	RET	
	RET	
	END	
