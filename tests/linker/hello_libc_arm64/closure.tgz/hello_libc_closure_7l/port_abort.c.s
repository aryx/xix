	TEXT	abort+0(SB),0,$8
	MOVW	$1,R0
	BL	exit+0(SB)
	RETURN	
	END	
