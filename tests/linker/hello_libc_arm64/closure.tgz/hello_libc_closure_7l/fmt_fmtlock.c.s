	TEXT	__fmtlock+0(SB),0,$0
	RETURN	
	TEXT	__fmtunlock+0(SB),0,$0
	RETURN	
	END	
