	TEXT	NaN+0(SB),0,$0
	CALL	__NaN+0(SB)
	RET	
	RET	
	TEXT	Inf+0(SB),0,$8
	MOVL	sign+0(FP),AX
	MOVL	AX,(SP)
	CALL	__Inf+0(SB)
	RET	
	RET	
	TEXT	isNaN+0(SB),0,$8
	MOVSD	x+0(FP),X0
	MOVSD	X0,(SP)
	CALL	__isNaN+0(SB)
	RET	
	RET	
	TEXT	isInf+0(SB),0,$16
	MOVSD	x+0(FP),X0
	MOVSD	X0,(SP)
	MOVL	sign+8(FP),CX
	MOVL	CX,8(SP)
	CALL	__isInf+0(SB)
	RET	
	RET	
	END	
