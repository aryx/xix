	TEXT	__assert_fail<>+0(SB),0,$32
	MOV	R0,s+0(FP)
	BL	strlen+0(SB)
	MOV	s+0(FP),R9
	MOVW	R0,.safe-4(SP)
	MOVW	$2,R0
	MOV	R9,16(R31)
	MOVW	.safe-4(SP),R2
	MOVW	R2,24(R31)
	BL	write+0(SB)
	MOVW	$2,R0
	MOV	$.string<>+0(SB),R5
	MOV	R5,16(R31)
	MOVW	$1,R2
	MOVW	R2,24(R31)
	BL	write+0(SB)
	BL	abort+0(SB)
	RETURN	
	DATA	_assert+0(SB)/8,$__assert_fail<>+0(SB)
	DATA	.string<>+0(SB)/8,$"\n\z\z\z\z\z\z\z"
	GLOBL	_assert+0(SB),$8
	GLOBL	.string<>+0(SB),$8
	END	
