	DATA	uvnan<>+0(SB)/4,$1
	DATA	uvnan<>+4(SB)/4,$2146435072
	DATA	uvinf<>+0(SB)/4,$0
	DATA	uvinf<>+4(SB)/4,$2146435072
	DATA	uvneginf<>+0(SB)/4,$0
	DATA	uvneginf<>+4(SB)/4,$4293918720
	TEXT	d2u<>+0(SB),0,$16
	FMOVD	d+0(FP),F7
	B	4(PC)
	B	2(PC)
	B	3(PC)
	B	-1(PC)
	B	-3(PC)
	FMOVD	F7,u-8(SP)
	MOV	u-8(SP),R0
	RETURN	
	RETURN	
	TEXT	u2d<>+0(SB),0,$16
	B	4(PC)
	B	2(PC)
	B	3(PC)
	B	-1(PC)
	B	-3(PC)
	MOV	R0,u-8(SP)
	FMOVD	u-8(SP),F0
	RETURN	
	RETURN	
	TEXT	__NaN+0(SB),0,$8
	MOV	uvnan<>+0(SB),R0
	BL	u2d<>+0(SB)
	RETURN	
	RETURN	
	TEXT	__isNaN+0(SB),0,$16
	FMOVD	d+0(FP),F7
	FMOVD	F7,8(R31)
	BL	d2u<>+0(SB)
	MOV	uvneginf<>+0(SB),R11
	MOV	uvinf<>+0(SB),R10
	AND	R10,R0,R2
	CMP	R10,R2
	BNE	5(PC)
	MVN	R11,R4
	AND	R4,R0,R4
	CMP	$0,R4
	BNE	2(PC)
	B	3(PC)
	MOVW	$1,R0
	B	2(PC)
	MOVW	$0,R0
	RETURN	
	RETURN	
	TEXT	__Inf+0(SB),0,$8
	MOV	uvneginf<>+0(SB),R11
	MOV	uvinf<>+0(SB),R10
	CMPW	$0,R0
	BGE	3(PC)
	MOV	R11,R0
	B	2(PC)
	MOV	R10,R0
	BL	u2d<>+0(SB)
	RETURN	
	RETURN	
	TEXT	__isInf+0(SB),0,$16
	FMOVD	d+0(FP),F7
	FMOVD	F7,8(R31)
	BL	d2u<>+0(SB)
	MOVW	sign+8(FP),R12
	MOV	uvinf<>+0(SB),R11
	MOV	uvneginf<>+0(SB),R10
	CMPW	$0,R12
	BNE	11(PC)
	CMP	R11,R0
	BEQ	4(PC)
	CMP	R10,R0
	BEQ	2(PC)
	B	3(PC)
	MOVW	$1,R0
	B	2(PC)
	MOVW	$0,R0
	RETURN	
	B	16(PC)
	CMPW	$0,R12
	BLE	8(PC)
	CMP	R11,R0
	BNE	3(PC)
	MOVW	$1,R0
	B	2(PC)
	MOVW	$0,R0
	RETURN	
	B	7(PC)
	CMP	R10,R0
	BNE	3(PC)
	MOVW	$1,R0
	B	2(PC)
	MOVW	$0,R0
	RETURN	
	RETURN	
	GLOBL	uvneginf<>+0(SB),$8
	GLOBL	uvinf<>+0(SB),$8
	GLOBL	uvnan<>+0(SB),$8
	END	
