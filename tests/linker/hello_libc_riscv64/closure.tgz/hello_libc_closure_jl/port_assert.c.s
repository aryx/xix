	TEXT	__assert_fail<>+0(SB),0,$24
	MOV	R8,s+0(FP)
	JAL	R1,strlen+0(SB)
	MOV	s+0(FP),R13
	MOVW	R8,.safe-4(SP)
	MOV	$2,R8
	MOV	R13,16(R2)
	MOVW	.safe-4(SP),R10
	MOVW	R10,24(R2)
	JAL	R1,write+0(SB)
	MOV	$2,R8
	MOV	$.string<>+0(SB),R11
	MOV	R11,16(R2)
	MOV	$1,R12
	MOVW	R12,24(R2)
	JAL	R1,write+0(SB)
	JAL	R1,abort+0(SB)
	RET	
	DATA	_assert+0(SB)/8,$__assert_fail<>+0(SB)
	DATA	.string<>+0(SB)/8,$"\n\z\z\z\z\z\z\z"
	GLOBL	_assert+0(SB),$8
	GLOBL	.string<>+0(SB),$8
	END	
