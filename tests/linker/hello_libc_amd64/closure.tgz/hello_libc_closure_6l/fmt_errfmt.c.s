	TEXT	__errfmt+0(SB),0,$24
	MOVL	errno+0(SB),CX
	MOVL	CX,(SP)
	CALL	strerror+0(SB)
	MOVQ	f+0(FP),CX
	MOVQ	CX,(SP)
	MOVQ	AX,8(SP)
	CALL	fmtstrcpy+0(SB)
	RET	
	RET	
	END	
