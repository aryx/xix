	TEXT	__fmtlock+0(SB),0,$0
	RET	
	TEXT	__fmtunlock+0(SB),0,$0
	RET	
	END	
