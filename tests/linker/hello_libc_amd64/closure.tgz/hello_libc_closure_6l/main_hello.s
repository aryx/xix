	TEXT	main+0(SB),0,$32
	DATA	.string<>+0(SB)/8,$"hello fr"
	DATA	.string<>+8(SB)/8,$"om libc."
	DATA	.string<>+16(SB)/8,$"a: %d + "
	DATA	.string<>+24(SB)/8,$"%d = %d\n"
	MOVQ	$.string<>+0(SB),AX
	MOVQ	AX,(SP)
	MOVL	$2,AX
	MOVL	AX,8(SP)
	MOVL	$2,AX
	MOVL	AX,16(SP)
	MOVL	$4,AX
	MOVL	AX,24(SP)
	CALL	print+0(SB)
	MOVL	$0,(SP)
	CALL	exit+0(SB)
	RET	
	DATA	.string<>+32(SB)/8,$"\z\z\z\z\z\z\z\z"
	GLOBL	.string<>+0(SB),$40
	END	
