	TEXT	strerror+0(SB),0,$0
	BNE	R1,R0,3(PC)
	DATA	.string<>+0(SB)/8,$"no error"
	MOVW	$.string<>+0(SB),R1
	RET	
	MOVW	$.string<>+9(SB),R1
	RET	
	RET	
	DATA	.string<>+8(SB)/8,$"\zerror\z\z"
	GLOBL	.string<>+0(SB),$16
	END	
