	TEXT	strerror+0(SB),0,$0
	CMPW	$0,R0
	BNE	3(PC)
	DATA	.string<>+0(SB)/8,$"no error"
	MOV	$.string<>+0(SB),R0
	RETURN	
	MOV	$.string<>+9(SB),R0
	RETURN	
	RETURN	
	DATA	.string<>+8(SB)/8,$"\zerror\z\z"
	GLOBL	.string<>+0(SB),$16
	END	
