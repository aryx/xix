	TEXT	print+0(SB),0,$40
	LEAQ	fmt+8(FP),AX
	MOVL	$1,CX
	MOVL	CX,(SP)
	MOVQ	fmt+0(FP),CX
	MOVQ	CX,8(SP)
	MOVQ	AX,16(SP)
	CALL	vfprint+0(SB)
	RET	
	RET	
	END	
