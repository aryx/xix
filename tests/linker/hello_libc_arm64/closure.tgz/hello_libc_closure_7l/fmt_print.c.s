	TEXT	print+0(SB),0,$40
	MOV	R0,fmt+0(FP)
	MOV	$fmt+0(FP),R2
	ADD	$8,R2,R2
	MOVW	$1,R0
	MOV	fmt+0(FP),R4
	MOV	R4,16(R31)
	MOV	R2,24(R31)
	BL	vfprint+0(SB)
	RETURN	
	RETURN	
	END	
