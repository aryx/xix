	TEXT	__assert_fail<>+0(SB),0,$16
	MOVW	R1,s+0(FP)
	JAL	strlen+0(SB)
	MOVW	s+0(FP),R4
	MOVW	R1,.safe-4(SP)
	MOVW	$2,R1
	MOVW	R4,8(R29)
	MOVW	.safe-4(SP),R3
	MOVW	R3,12(R29)
	JAL	write+0(SB)
	MOVW	$2,R1
	MOVW	$.string<>+0(SB),R6
	MOVW	R6,8(R29)
	MOVW	$1,R3
	MOVW	R3,12(R29)
	JAL	write+0(SB)
	JAL	abort+0(SB)
	RET	
	DATA	_assert+0(SB)/4,$__assert_fail<>+0(SB)
	DATA	.string<>+0(SB)/8,$"\n\z\z\z\z\z\z\z"
	GLOBL	_assert+0(SB),$4
	GLOBL	.string<>+0(SB),$8
	END	
