	TEXT	print+0(SB),0,$20
	MOVW	R1,fmt+0(FP)
	MOVW	$fmt+0(FP),R3
	ADDU	$4,R3
	MOVW	$1,R1
	MOVW	fmt+0(FP),R5
	MOVW	R5,8(R29)
	MOVW	R3,12(R29)
	JAL	vfprint+0(SB)
	RET	
	RET	
	END	
