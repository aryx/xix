	TEXT	fmtlocaleinit+0(SB),0,$0
	MOVW	grouping+12(FP),R8
	MOVW	decimal+4(FP),R7
	MOVW	R0,R6
	CMP	$0,R7
	BEQ	4(PC)
	MOVB	0(R7),R4
	CMP	$0,R4
	BNE	2(PC)
	MOVW	$.string<>+0(SB),R7
	MOVW	thousands+8(FP),R2
	CMP	$0,R2
	MOVW.EQ	$.string<>+2(SB),R4
	MOVW.EQ	R4,thousands+8(FP)
	CMP	$0,R8
	MOVW.EQ	$.string<>+4(SB),R8
	MOVW	R7,48(R6)
	MOVW	thousands+8(FP),R1
	MOVW	R1,52(R6)
	MOVW	R8,56(R6)
	RET	
	TEXT	__needsep+0(SB),0,$4
	MOVW	grouping+4(FP),R8
	MOVW	R0,R7
	MOVW	0(R0),R5
	ADD	$1,R5
	MOVW	R5,0(R0)
	MOVW	0(R8),R6
	MOVBU	0(R6),R6
	CMP	$255,R6
	BEQ	3(PC)
	CMP	$127,R6
	BNE	2(PC)
	B	3(PC)
	CMP	$0,R6
	BNE	3(PC)
	MOVW	$0,R0
	RET	
	MOVW	0(R0),R3
	CMP	R6,R3
	BLE	10(PC)
	MOVW	0(R8),R4
	MOVB	1(R4),R4
	CMP	$0,R4
	MOVW.NE	0(R8),R4
	ADD.NE	$1,R4
	MOVW.NE	R4,0(R8)
	MOVW	$1,R0
	MOVW	R0,0(R7)
	RET	
	MOVW	$0,R0
	RET	
	RET	
	DATA	.string<>+0(SB)/8,$"\056\z\054\z\003\z\z\z"
	GLOBL	.string<>+0(SB),$8
	END	
