	TEXT	__errfmt+0(SB),0,$12
	MOVW	errno+0(SB),R3
	MOVW	R1,f+0(FP)
	MOVW	R3,R1
	JAL	strerror+0(SB)
	MOVW	f+0(FP),R4
	MOVW	R1,R3
	MOVW	R4,R1
	MOVW	R3,8(R29)
	JAL	fmtstrcpy+0(SB)
	RET	
	RET	
	END	
