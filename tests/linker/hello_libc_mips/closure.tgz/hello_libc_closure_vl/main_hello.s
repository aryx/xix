	TEXT	main+0(SB),0,$16
	DATA	.string<>+0(SB)/8,$"hello fr"
	DATA	.string<>+8(SB)/8,$"om libc\056"
	DATA	.string<>+16(SB)/8,$"a\072 %d \053 "
	DATA	.string<>+24(SB)/8,$"%d \075 %d\n"
	MOVW	$.string<>+0(SB),R1
	MOVW	$2,R2
	MOVW	R2,8(R29)
	MOVW	$2,R4
	MOVW	R4,12(R29)
	MOVW	$4,R6
	MOVW	R6,16(R29)
	JAL	print+0(SB)
	MOVW	R0,R1
	JAL	exit+0(SB)
	RET	
	DATA	.string<>+32(SB)/8,$"\z\z\z\z\z\z\z\z"
	GLOBL	.string<>+0(SB),$40
	END	
