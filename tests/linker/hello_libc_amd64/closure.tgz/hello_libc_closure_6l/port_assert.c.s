	TEXT	__assert_fail<>+0(SB),0,$32
	MOVQ	s+0(FP),CX
	MOVQ	CX,(SP)
	CALL	strlen+0(SB)
	MOVL	AX,.safe+-4(SP)
	MOVL	$2,AX
	MOVL	AX,(SP)
	MOVQ	s+0(FP),AX
	MOVQ	AX,8(SP)
	MOVL	.safe+-4(SP),AX
	MOVL	AX,16(SP)
	CALL	write+0(SB)
	MOVL	$2,AX
	MOVL	AX,(SP)
	MOVQ	$.string<>+0(SB),AX
	MOVQ	AX,8(SP)
	MOVL	$1,AX
	MOVL	AX,16(SP)
	CALL	write+0(SB)
	CALL	abort+0(SB)
	RET	
	DATA	_assert+0(SB)/8,$__assert_fail<>+0(SB)
	DATA	.string<>+0(SB)/8,$"\n\z\z\z\z\z\z\z"
	GLOBL	_assert+0(SB),$8
	GLOBL	.string<>+0(SB),$8
	END	
