	GLOBL	_mainargc+0(SB),$8
	GLOBL	_mainargv+0(SB),$8
	END	
