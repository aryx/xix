	GLOBL	_mainargc+0(SB),$4
	GLOBL	_mainargv+0(SB),$4
	END	
