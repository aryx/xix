	TEXT	strerror+0(SB),0,$0
	CMP	$0,R0
	DATA	.string<>+0(SB)/8,$"no error"
	MOVW.EQ	$.string<>+0(SB),R0
	RET.EQ	
	MOVW	$.string<>+9(SB),R0
	RET	
	RET	
	DATA	.string<>+8(SB)/8,$"\zerror\z\z"
	GLOBL	.string<>+0(SB),$16
	END	
