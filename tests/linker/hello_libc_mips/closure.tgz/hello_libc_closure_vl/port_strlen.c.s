	TEXT	strlen+0(SB),0,$8
	MOVW	R1,s+0(FP)
	MOVW	$0,8(R29)
	JAL	strchr+0(SB)
	MOVW	s+0(FP),R3
	SUBU	R3,R1
	RET	
	RET	
	END	
