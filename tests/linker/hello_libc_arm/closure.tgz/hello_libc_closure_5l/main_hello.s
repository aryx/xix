	TEXT	main+0(SB),0,$16
	DATA	.string<>+0(SB)/8,$"hello fr"
	DATA	.string<>+8(SB)/8,$"om libc\056"
	DATA	.string<>+16(SB)/8,$"a\072 %d \053 "
	DATA	.string<>+24(SB)/8,$"%d \075 %d\n"
	MOVW	$.string<>+0(SB),R0
	MOVW	$2,R1
	MOVW	R1,8(R13)
	MOVW	R1,12(R13)
	MOVW	$4,R5
	MOVW	R5,16(R13)
	BL	print+0(SB)
	MOVW	$0,R0
	BL	exit+0(SB)
	RET	
	DATA	.string<>+32(SB)/8,$"\z\z\z\z\z\z\z\z"
	GLOBL	.string<>+0(SB),$40
	END	
