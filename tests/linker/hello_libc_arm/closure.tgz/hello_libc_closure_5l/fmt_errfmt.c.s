	TEXT	__errfmt+0(SB),0,$12
	MOVW	errno+0(SB),R2
	MOVW	R0,f+0(FP)
	MOVW	R2,R0
	BL	strerror+0(SB)
	MOVW	f+0(FP),R3
	MOVW	R0,R2
	MOVW	R3,R0
	MOVW	R2,8(R13)
	BL	fmtstrcpy+0(SB)
	RET	
	RET	
	END	
