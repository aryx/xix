	TEXT	NaN+0(SB),0,$0
	BL	__NaN+0(SB)
	RET	
	RET	
	TEXT	Inf+0(SB),0,$4
	BL	__Inf+0(SB)
	RET	
	RET	
	TEXT	isNaN+0(SB),0,$8
	MOVD	x+0(FP),F2
	MOVD	F2,4(R13)
	BL	__isNaN+0(SB)
	RET	
	RET	
	TEXT	isInf+0(SB),0,$12
	MOVD	x+0(FP),F2
	MOVW	sign+8(FP),R2
	MOVD	F2,4(R13)
	MOVW	R2,12(R13)
	BL	__isInf+0(SB)
	RET	
	RET	
	END	
