	TEXT	strlen+0(SB),0,$8
	MOVW	R8,s+0(FP)
	MOVW	$0,8(R2)
	JAL	R1,strchr+0(SB)
	MOVW	s+0(FP),R10
	SUB	R10,R8
	RET	
	RET	
	END	
