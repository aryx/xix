	TEXT	strtod+0(SB),0,$16
	MOV	e+8(FP),R11
	MOV	R11,16(R2)
	JAL	R1,fmtstrtod+0(SB)
	RET	
	RET	
	END	
