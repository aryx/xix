	TEXT	__errfmt+0(SB),0,$24
	MOVW	errno+0(SB),R10
	MOV	R8,f+0(FP)
	MOVW	R10,R8
	JAL	R1,strerror+0(SB)
	MOV	f+0(FP),R11
	MOV	R8,R10
	MOV	R11,R8
	MOV	R10,16(R2)
	JAL	R1,fmtstrcpy+0(SB)
	RET	
	RET	
	END	
