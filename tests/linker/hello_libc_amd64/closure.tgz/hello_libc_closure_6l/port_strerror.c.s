	TEXT	strerror+0(SB),0,$0
	CMPL	e+0(FP),$0
	JNE	3(PC)
	DATA	.string<>+0(SB)/8,$"no error"
	MOVQ	$.string<>+0(SB),AX
	RET	
	MOVQ	$.string<>+9(SB),AX
	RET	
	RET	
	DATA	.string<>+8(SB)/8,$"\zerror\z\z"
	GLOBL	.string<>+0(SB),$16
	END	
