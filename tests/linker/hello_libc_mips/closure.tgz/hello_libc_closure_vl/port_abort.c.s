	TEXT	abort+0(SB),0,$4
	MOVW	$1,R1
	JAL	exit+0(SB)
	RET	
	END	
