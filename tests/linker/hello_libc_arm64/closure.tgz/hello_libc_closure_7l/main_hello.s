	TEXT	main+0(SB),0,$32
	DATA	.string<>+0(SB)/8,$"hello fr"
	DATA	.string<>+8(SB)/8,$"om libc\056"
	DATA	.string<>+16(SB)/8,$"a\072 %d \053 "
	DATA	.string<>+24(SB)/8,$"%d \075 %d\n"
	MOV	$.string<>+0(SB),R0
	MOVW	$2,R1
	MOVW	R1,16(R31)
	MOVW	R1,24(R31)
	MOVW	$4,R5
	MOVW	R5,32(R31)
	BL	print+0(SB)
	MOVW	$0,R0
	BL	exit+0(SB)
	RETURN	
	DATA	.string<>+32(SB)/8,$"\z\z\z\z\z\z\z\z"
	GLOBL	.string<>+0(SB),$40
	END	
