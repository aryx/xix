	TEXT	strtod+0(SB),0,$16
	MOVQ	s+0(FP),AX
	MOVQ	AX,(SP)
	MOVQ	e+8(FP),AX
	MOVQ	AX,8(SP)
	CALL	fmtstrtod+0(SB)
	RET	
	RET	
	END	
