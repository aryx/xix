	TEXT	abort+0(SB),0,$4
	MOVW	$1,R0
	BL	exit+0(SB)
	RET	
	END	
