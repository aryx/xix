	TEXT	__errfmt+0(SB),0,$12
	MOVW	errno+0(SB),R10
	MOVW	R8,f+0(FP)
	MOVW	R10,R8
	JAL	R1,strerror+0(SB)
	MOVW	f+0(FP),R11
	MOVW	R8,R10
	MOVW	R11,R8
	MOVW	R10,8(R2)
	JAL	R1,fmtstrcpy+0(SB)
	RET	
	RET	
	END	
