	TEXT	abort+0(SB),0,$8
	MOVL	$1,AX
	MOVL	AX,(SP)
	CALL	exit+0(SB)
	RET	
	END	
