	TEXT	print+0(SB),0,$20
	MOVW	R0,fmt+0(FP)
	MOVW	$fmt+0(FP),R2
	ADD	$4,R2,R2
	MOVW	$1,R0
	MOVW	fmt+0(FP),R4
	MOVW	R4,8(R13)
	MOVW	R2,12(R13)
	BL	vfprint+0(SB)
	RET	
	RET	
	END	
