	TEXT	strtod+0(SB),0,$8
	MOVW	e+4(FP),R11
	MOVW	R11,8(R2)
	JAL	R1,fmtstrtod+0(SB)
	RET	
	RET	
	END	
