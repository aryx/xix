	TEXT	fmtlocaleinit+0(SB),0,$0
	MOVQ	thousands+16(FP),SI
	MOVQ	grouping+24(FP),BP
	MOVQ	f+0(FP),BX
	MOVQ	decimal+8(FP),DX
	CMPQ	DX,$0
	JEQ	5(PC)
	MOVBLSX	(DX),AX
	CMPL	AX,$0
	JEQ	2(PC)
	JMP	2(PC)
	MOVQ	$.string<>+0(SB),DX
	CMPQ	SI,$0
	JNE	2(PC)
	MOVQ	$.string<>+2(SB),SI
	CMPQ	BP,$0
	JNE	2(PC)
	MOVQ	$.string<>+4(SB),BP
	MOVQ	DX,80(BX)
	MOVQ	SI,88(BX)
	MOVQ	BP,96(BX)
	RET	
	TEXT	__needsep+0(SB),0,$8
	MOVQ	ndig+0(FP),BX
	MOVQ	grouping+8(FP),DX
	INCL	(BX)
	MOVQ	(DX),CX
	MOVBLZX	(CX),CX
	CMPL	CX,$255
	JEQ	3(PC)
	CMPL	CX,$127
	JNE	2(PC)
	JMP	4(PC)
	CMPL	CX,$0
	JEQ	2(PC)
	JMP	3(PC)
	MOVL	$0,AX
	RET	
	MOVL	(BX),AX
	CMPL	AX,CX
	JLE	9(PC)
	MOVQ	(DX),AX
	MOVBLSX	1(AX),AX
	CMPL	AX,$0
	JEQ	2(PC)
	INCQ	(DX)
	MOVL	$1,(BX)
	MOVL	$1,AX
	RET	
	MOVL	$0,AX
	RET	
	RET	
	DATA	.string<>+0(SB)/8,$".\z,\z\003\z\z\z"
	GLOBL	.string<>+0(SB),$8
	END	
