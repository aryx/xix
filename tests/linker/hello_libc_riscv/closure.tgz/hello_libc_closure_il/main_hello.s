	TEXT	main+0(SB),0,$16
	DATA	.string<>+0(SB)/8,$"hello fr"
	DATA	.string<>+8(SB)/8,$"om libc\056"
	DATA	.string<>+16(SB)/8,$"a\072 %d \053 "
	DATA	.string<>+24(SB)/8,$"%d \075 %d\n"
	MOV	$.string<>+0(SB),R8
	MOV	$2,R9
	MOVW	R9,8(R2)
	MOV	$2,R10
	MOVW	R10,12(R2)
	MOV	$4,R11
	MOVW	R11,16(R2)
	JAL	R1,print+0(SB)
	MOV	R0,R8
	JAL	R1,exit+0(SB)
	RET	
	DATA	.string<>+32(SB)/8,$"\z\z\z\z\z\z\z\z"
	GLOBL	.string<>+0(SB),$40
	END	
