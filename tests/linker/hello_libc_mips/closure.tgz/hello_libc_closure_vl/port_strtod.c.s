	TEXT	strtod+0(SB),0,$8
	MOVW	e+4(FP),R5
	MOVW	R5,8(R29)
	JAL	fmtstrtod+0(SB)
	RET	
	RET	
	END	
