	TEXT	__errfmt+0(SB),0,$24
	MOVW	errno+0(SB),R9
	MOV	R0,f+0(FP)
	MOVW	R9,R0
	BL	strerror+0(SB)
	MOV	f+0(FP),R10
	MOV	R0,R9
	MOV	R10,R0
	MOV	R9,16(R31)
	BL	fmtstrcpy+0(SB)
	RETURN	
	RETURN	
	END	
