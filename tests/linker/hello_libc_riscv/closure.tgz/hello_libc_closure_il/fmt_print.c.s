	TEXT	print+0(SB),0,$20
	MOVW	R8,fmt+0(FP)
	MOV	$fmt+0(FP),R9
	ADD	$4,R9
	MOV	$1,R8
	MOVW	fmt+0(FP),R10
	MOVW	R10,8(R2)
	MOVW	R9,12(R2)
	JAL	R1,vfprint+0(SB)
	RET	
	RET	
	END	
