	TEXT	strtod+0(SB),0,$16
	MOV	e+8(FP),R10
	MOV	R10,16(R31)
	BL	fmtstrtod+0(SB)
	RETURN	
	RETURN	
	END	
