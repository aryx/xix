	TEXT	strtod+0(SB),0,$8
	MOVW	e+4(FP),R4
	MOVW	R4,8(R13)
	BL	fmtstrtod+0(SB)
	RET	
	RET	
	END	
