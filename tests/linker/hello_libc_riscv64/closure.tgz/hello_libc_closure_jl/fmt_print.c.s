	TEXT	print+0(SB),0,$40
	MOV	R8,fmt+0(FP)
	MOV	$fmt+0(FP),R9
	ADD	$8,R9
	MOV	$1,R8
	MOV	fmt+0(FP),R10
	MOV	R10,16(R2)
	MOV	R9,24(R2)
	JAL	R1,vfprint+0(SB)
	RET	
	RET	
	END	
