	TEXT	__assert_fail<>+0(SB),0,$16
	MOVW	R0,s+0(FP)
	BL	strlen+0(SB)
	MOVW	s+0(FP),R3
	MOVW	R0,.safe-4(SP)
	MOVW	$2,R0
	MOVW	R3,8(R13)
	MOVW	.safe-4(SP),R2
	MOVW	R2,12(R13)
	BL	write+0(SB)
	MOVW	$2,R0
	MOVW	$.string<>+0(SB),R5
	MOVW	R5,8(R13)
	MOVW	$1,R2
	MOVW	R2,12(R13)
	BL	write+0(SB)
	BL	abort+0(SB)
	RET	
	DATA	_assert+0(SB)/4,$__assert_fail<>+0(SB)
	DATA	.string<>+0(SB)/8,$"\n\z\z\z\z\z\z\z"
	GLOBL	_assert+0(SB),$4
	GLOBL	.string<>+0(SB),$8
	END	
