	TEXT	abort+0(SB),0,$8
	MOV	$1,R8
	JAL	R1,exit+0(SB)
	RET	
	END	
