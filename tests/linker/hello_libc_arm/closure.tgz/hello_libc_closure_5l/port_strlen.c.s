	TEXT	strlen+0(SB),0,$8
	MOVW	R0,s+0(FP)
	MOVW	$0,R4
	MOVW	R4,8(R13)
	BL	strchr+0(SB)
	MOVW	s+0(FP),R2
	SUB	R2,R0
	RET	
	RET	
	END	
