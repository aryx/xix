	TEXT	strerror+0(SB),0,$0
	BNE	R0,R8,3(PC)
	DATA	.string<>+0(SB)/8,$"no error"
	MOV	$.string<>+0(SB),R8
	RET	
	MOV	$.string<>+9(SB),R8
	RET	
	RET	
	DATA	.string<>+8(SB)/8,$"\zerror\z\z"
	GLOBL	.string<>+0(SB),$16
	END	
