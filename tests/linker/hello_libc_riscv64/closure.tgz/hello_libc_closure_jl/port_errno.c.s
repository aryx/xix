	GLOBL	errno+0(SB),$4
	END	
